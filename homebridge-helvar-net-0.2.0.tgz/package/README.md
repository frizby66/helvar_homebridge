# homebridge-helvar-net

Multi-router Helvar lighting control for Homebridge and Apple Home. Version 0.1.0 is an initial implementation tested against a TCP router simulator and a Homebridge API test double. Physical-router commissioning and an installed Homebridge smoke test remain required.

## Features

- Independently configured router IPv4 addresses, ports, request timeouts and polling intervals.
- Group and individual load on/off, dimming, fade times and remembered positive brightness.
- Group scene switches show the last recalled scene per router, group and block; device scene switches remain momentary.
- HomeKit feedback from individual loads or a configured representative load for a group.
- Acknowledged commands, bounded requests, queued operations per router and reconnection on the next request after disconnection. Failed controls are not replayed.
- Cached accessory reconciliation and stable identities across IP or display-name changes.
- Homebridge Config UI settings schema, read-only discovery and Designer-file string inspection.
- No runtime dependencies beyond Node.js and Homebridge.

## Install

Use Node.js 20 or newer with a version supported by your Homebridge release. The declared Homebridge range is 1.8.x through 2.x; compatibility across that range has not been physically verified.

From this package directory on your Homebridge host:

```sh
npm install -g . --omit=dev
```

Alternatively install the supplied package archive:

```sh
npm install -g /path/to/homebridge-helvar-net-0.1.0.tgz
```

Use the npm executable belonging to your Homebridge installation. Restart Homebridge after adding the configuration. Add the platform object from `examples/config.json` to the existing `platforms` array in Homebridge's config; preserve its other platform entries. The plugin alias is `HelvarNet`.

**All IPs, group numbers, scene numbers and device addresses in the example are illustrative.** The `192.0.2.x` addresses are documentation placeholders. Replace them with verified values from your installation. The Barnsley template deliberately has empty accessory lists until the numeric mappings are confirmed.

## Configuration

```json
{
  "platform": "HelvarNet",
  "name": "Helvar",
  "instanceId": "my-house",
  "routers": [{
    "id": "plant-room",
    "host": "192.0.2.10",
    "model": "920",
    "pollInterval": 15,
    "lights": [{
      "id": "lounge",
      "name": "Lounge",
      "group": 17,
      "feedbackAddress": "1.1.3.10"
    }],
    "scenes": [{
      "id": "evening",
      "name": "Evening",
      "group": 17,
      "block": 1,
      "scene": 2
    }]
  }]
}
```

| Field | Meaning / default |
| --- | --- |
| `instanceId` | Stable unique ID for each platform instance; defaults to `default` |
| Router `id` | Unique stable ID within the platform; preserve when IP changes |
| `host` | Router IPv4 address; required |
| `port` | TCP port; default 50000 |
| `timeoutMs` | Connect and per-request timeout; default 3000 |
| `pollInterval` | Seconds between completed polling cycles; default 15, 0 disables background polling |
| `fadeTimeMs` | Default fade in milliseconds; default 700; accessory may override |
| Accessory `id` | Unique across lights and scenes on that router; preserve when renaming |
| `group` | Group index 1–16383; use either this or `address` |
| `address` | Full Helvar `cluster.router.subnet.device` address; use either this or `group` |
| `feedbackAddress` | Optional load to represent a group's current level |
| `dimmable` | Light dimmer control; default true; false exposes on/off only |
| `defaultBrightness` | Initial turn-on percentage, 1–100; default 100 |
| Scene `block` / `scene` | Block 1–8 (default 1), scene 1–16 (required) |

A direct-address light queries its own output. A group with `feedbackAddress` reports that single load's state, which can differ from other members in a mixed scene. Choose a load that reliably represents the zone. A group without it starts with unavailable state until its first successful HomeKit control and thereafter reports locally tracked state. It cannot observe wall panels, schedules or other controllers. An unreachable feedback load produces a HomeKit communication error. `pollInterval: 0` still permits queries when HomeKit reads characteristics.

Group scene switches show the last recalled scene in their configured block using query 103. Recalling a scene turns the other configured switches for that same router/group/block off. Wall-panel recalls are reflected through the router polling interval (default 15 seconds), and accessory reads refresh stale state. The displayed state describes the last recalled scene; individual dimming afterwards may leave that scene reported. Scene 15 is not intrinsically an Off scene, but the live Barnsley kitchen data shows its stored levels are zero. Turning a scene switch off sends no router command and its state is restored; recall the configured Off scene explicitly. Device-address scene switches remain momentary. Failed queries mark group scene state unavailable. Different groups, blocks and routers are tracked independently. Use Apple Home scenes or automations to combine switches across routers. There is no cross-router transaction or rollback.

Group commands can propagate throughout a connected Helvar workgroup. Configure each logical group once through your chosen router, even if its loads span several routers. Separate workgroups may reuse group numbers. The stable router IDs keep those accessories distinct.

Set `dimmable: false` for lighting relays. This plugin models lighting only; do not expose blinds, emergency tests or unrelated S-DIM relay outputs as lights. Colour, tunable white, occupancy sensors, push routing and automatic accessory creation are outside this version's scope.

## Read-only discovery

Run this on the same network as the routers:

```sh
helvar-discover 192.0.2.10
helvar-discover 192.0.2.11 50000
# Or from the source directory:
node bin/discover.js 192.0.2.10
```

Outputs JSON containing group IDs, Designer names, member addresses, load candidates and warnings. It only sends query commands; it does not turn lights on or modify Designer. Discovery uses HelvarNET v2 group enumeration/membership. Unsupported firmware requires manual configuration from Designer. It may take some time on larger sites. A candidate responds to a load-level query; verify the actual load and group in Designer before assigning it. Discovery does not discover IPs, import scenes or automatically expose accessories.

## Attached Barnsley project

The supplied file is a proprietary binary `.design`, 174,887 bytes. Inspection found two `ZRouter` records, with labels `Plant Room` and `Utillity Room Loft`, and DALI, S-DIM and DMX sections. `Router_924` also appears as a serialized class label: Helvar 924 is a touch panel, so that string alone is not evidence of another lighting router.

Examples of readable load labels include `lounge lv`, `study dl`, `Kitchen Island`, `Kitchen Under Unit` and `Dining Room Wall Lights`. These strings do **not** prove group IDs or numerical addresses. No speculative binary decoding is used for control configuration. The file remains unchanged.

```sh
helvar-inspect-design '/path/to/project.design'
```

The inspection tool reports source size, SHA-256 and heuristic readable strings. `examples/barnsley-template.json` contains the observed router labels and placeholder IPs, ready for verified mappings. Use live discovery and Designer's device/group views to fill it in.

## Commissioning

1. Confirm the routers' IPs and that the Homebridge host can reach their HelvarNET TCP port. Enable third-party HelvarNET access in Designer if your installation requires it.
2. Discover each separate workgroup and check group, load and scene mappings in Designer. Start with one known lighting circuit per router.
3. Install the package, configure those test circuits and restart Homebridge. Confirm accessories appear in Apple Home.
4. Test on/off, dimming, configured fade and scene recall. Check a wall-panel change reaches HomeKit for lights with feedback.
5. Test disconnection/recovery, then add the remaining verified circuits. For larger installations, raise the polling interval and use a Homebridge child bridge as appropriate.

The implementation targets 910/920 and other 900-series routers that provide the same HelvarNET command set. Model labels do not enable otherwise unsupported firmware features. Actual compatibility must be confirmed per router/firmware.

HelvarNET is unencrypted. Keep it on your trusted local lighting network and do not forward its port to the internet. HomeKit remote access uses your Apple home hub.

## Development and protocol references

```sh
npm test
npm run check
npm pack
```

Tests exercise framing, multipart replies, request correlation, acknowledgements, errors, timeouts, recovery, independent routers, Homebridge state handlers, cache reconciliation and read-only discovery. No real routers are contacted by tests.

Implemented from the [Helvar Designer HelvarNET protocol reference](https://aca.im/driver_docs/Helvar/HelvarNet-Overview.pdf) and the [Homebridge dynamic platform API](https://developers.homebridge.io/homebridge/interfaces/DynamicPlatformPlugin.html). Control uses version 1; discovery uses version 2. Diagnostic success acknowledges router acceptance, not physical lamp operation. Load polling supplies feedback, including the documented off-state flags and DALI level rounding.

MIT licensed. This package has not been published to npm or installed into your running Homebridge instance.
