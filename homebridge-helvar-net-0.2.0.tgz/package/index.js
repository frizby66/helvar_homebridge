'use strict';
const { HelvarPlatform } = require('./lib/platform');
module.exports = api => api.registerPlatform('homebridge-helvar-net', 'HelvarNet', HelvarPlatform);
