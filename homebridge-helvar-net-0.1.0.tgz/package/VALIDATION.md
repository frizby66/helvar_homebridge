# Validation — 4 October 2026

Result: all 9 automated tests passed using the bundled Node.js runtime on the Mac mini. All source JavaScript syntax checks and four JSON configuration/package parse checks passed.

Coverage: protocol command formatting and fade conversion; load-level off flags; input validation; fragmented/coalesced TCP replies; multipart replies with repeated or omitted headers; push-message filtering; request queueing; diagnostic success/failure; timeout and subsequent reconnection; independent routers; Homebridge dimming, remembered brightness and scene reset; accessory restoration/removal; query-only discovery.

Tests use local simulated TCP routers and a Homebridge API test double. They do not establish compatibility with a physical 920, other 900-series hardware or a running Homebridge installation. No real lighting was controlled. Complete the README commissioning steps before treating the plugin as production verified.

The original attachment was read unchanged:

- Size: 174,887 bytes.
- SHA-256: `30f9ad4530d898fe954b951d509d3cdce0e7312e05929ee9c57ab7de268ea788`.
- Heuristic inspection found router/load labels; numeric configuration was not inferred from the binary format.

No npm publication, Homebridge installation or lighting-router configuration changes were performed.
